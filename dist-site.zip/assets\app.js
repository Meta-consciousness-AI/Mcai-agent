
(function(){
  const input=document.getElementById('search');
  const cards=[...document.querySelectorAll('[data-card]')];
  const chips=[...document.querySelectorAll('.chip')];
  let cat='all';
  function apply(){
    const q=(input&&input.value||'').trim().toLowerCase();
    cards.forEach(c=>{
      const okCat = cat==='all' ? true
        : (cat==='derived' ? c.dataset.kind==='derived' : c.dataset.cat===cat);
      const okQ=!q||c.dataset.text.includes(q);
      c.style.display=(okCat&&okQ)?'':'none';
    });
  }
  if(input)input.addEventListener('input',apply);
  chips.forEach(ch=>ch.addEventListener('click',()=>{
    chips.forEach(x=>x.classList.remove('active'));
    ch.classList.add('active');cat=ch.dataset.cat;apply();
  }));
  const rebuild=document.getElementById('rebuild');
  if(rebuild)rebuild.addEventListener('click',async()=>{
    rebuild.disabled=true;const old=rebuild.textContent;rebuild.textContent='重建中…';
    try{
      const r=await fetch('/api/rebuild',{method:'POST'});
      const j=await r.json();
      rebuild.textContent=j.ok?('已重建 '+j.concepts+' 个概念'):'重建失败';
      if(j.ok)setTimeout(()=>location.reload(),900);
    }catch(e){rebuild.textContent='需要本地服务';}
    setTimeout(()=>{rebuild.disabled=false;rebuild.textContent=old},2500);
  });
})();
