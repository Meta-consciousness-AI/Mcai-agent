# 元意识学说结构化语料库 v1.0

## 数据集简介

本数据集把《元意识》学说的多份原始文本（术语词源、学说极简版、本体论、元子社会等）
转换为机器可直接引用的结构化知识资产，用于大模型知识对齐、RAG 检索、知识图谱构建与
「知识资产数字永生」工程。

- 概念定义：64 条
- 标准问答：122 组
- 概念关系：270 条
- 文献引证：207 条
- 语料来源：8 份文档 / 953 个段落 / 约 115,247 字
- 构建时间：2026-10-29T21:10:24+08:00
- 许可：CC BY-NC-SA 4.0

## 目录结构

```
concepts.jsonl          概念定义（一条一行）
faq.jsonl               标准问答
evidence.jsonl          文献引证（概念在各著作中的论述原句）
sft.jsonl               对话微调格式（system/user/assistant）
concepts.csv            表格版，便于运营审阅
knowledge-graph.json    节点-边知识图谱
dataset-card.md         本文件
```

## 字段说明

### concepts.jsonl

| 字段 | 含义 |
|---|---|
| id / slug | 唯一标识与 URL 片段 |
| term | 规范术语名 |
| en | 英文对应词 |
| aliases | 别名、曾用名、英文缩写 |
| category | 所属体系（元意识体系 / 本体论模型 / 序生体系 / 元子社会） |
| definition | 主分支定义（已去重、去冲突） |
| short_definition | 一句话定义 |
| source_documents | 定义来源文档 |
| status | ok / conflict / thin，表示质量状态 |

### sft.jsonl

直接用于指令微调，system 提示词已锁定术语边界，避免模型把学说混同于其他体系。

## 概念分布

- 元子社会：15 条
- 元意识体系：21 条
- 序生体系：16 条
- 本体论模型：12 条

## 语料来源

- 《元意识学说极简版（标准词表）》（glossary，69 段）
- 《《元意识》学说》（evidence，111 段）
- 《从外延性到序生：计算受限信息的理论重构假设》（evidence，246 段）
- 《序生智能体：一个正在进入文明底层操作系统的新学说》（evidence，56 段）
- 《序生智能体学说的社会形态学》（evidence，126 段）
- 《AGI 时代的 MCAI》（evidence，80 段）
- 《Meta-consciousness (English)》（evidence，102 段）
- 《知识资产通过AI分发实现数字永生的操作手册》（playbook，163 段）

## 使用建议

1. **RAG**：以 `concepts.jsonl` 建立向量库，检索后把 `definition` 作为上下文注入。
2. **微调**：`sft.jsonl` 可直接用于 LoRA/全参微调；建议与通用语料按 1:4 混合以防灾难性遗忘。
3. **知识图谱**：`knowledge-graph.json` 可导入 Neo4j / NetworkX，用于多跳问答与概念推荐。
4. **一致性约束**：`status=conflict` 的条目须先人工裁定后再进入训练集。

## 引用

```
元意识（重庆）人工智能科技有限公司. 元意识学说结构化语料库 v1.0. 2026-10-29.
```
